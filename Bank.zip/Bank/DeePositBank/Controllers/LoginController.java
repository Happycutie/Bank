package com.example.deepositbank.Controllers;


import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Views.AccountType;
import javafx.collections.FXCollections;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;


public class LoginController implements Initializable {
    public ChoiceBox<AccountType>acc_selector;
    public Label bank_account_number_lbl;
    public TextField bank_account_number_fld;
    public TextField password_fld;
    public Button login_btn;
    public Label error_lbl;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        acc_selector.setItems(FXCollections.observableArrayList(AccountType.CUSTOMER, AccountType.ACCOUNT_MANAGER));
        acc_selector.setValue(Model.getInstance().getViewFactory().getLoginAccountType());
        acc_selector.valueProperty().addListener(observable -> setAcc_selector());
        login_btn.setOnAction(event -> onLogin());
    }


    private void onLogin() {
        Stage stage = (Stage) error_lbl.getScene().getWindow();
        if (Model.getInstance().getViewFactory().getLoginAccountType() == AccountType.CUSTOMER){
            // Evaluate Customer Login Credentials
            Model.getInstance().evaluateCustomerCred(bank_account_number_fld.getText(), password_fld.getText());
            if (Model.getInstance().getCustomerLoginSuccessFlag()){
                Model.getInstance().getViewFactory().showCustomerWindow();
                // Close the login stage
                Model.getInstance().getViewFactory().closeStage(stage);
            } else {
                bank_account_number_fld.setText("");
                password_fld.setText("");
                error_lbl.setText("No Such Login Credentials.");
            }
        } else {
            // Evaluate AccountManager Login Credentials
            Model.getInstance().evaluateAdminCred( bank_account_number_fld.getText(), password_fld.getText());
            if (Model.getInstance().getAccountManagerLoginSuccessFlag()){
                Model.getInstance().getViewFactory().showAccountManagerWindow();
                // Close the login stage
                Model.getInstance().getViewFactory().closeStage(stage);
            } else {
                bank_account_number_fld.setText("");
                password_fld.setText("");
                error_lbl.setText("No Such Login Credentials");
            }
        }
    }

    private void setAcc_selector() {
        Model.getInstance().getViewFactory().setLoginAccountType(acc_selector.getValue());
        // Change Account Number label accordingly
        if (acc_selector.getValue() == AccountType.ACCOUNT_MANAGER){
            bank_account_number_lbl.setText("Username:");
        } else {
            bank_account_number_lbl.setText("Account Number:");
        }
    }
}