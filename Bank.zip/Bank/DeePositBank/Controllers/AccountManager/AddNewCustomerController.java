package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.BasicAccount;
import com.example.deepositbank.Models.IsaAccount;
import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Models.RewardAccount;
import com.example.deepositbank.Views.BankAccountType;
import com.example.deepositbank.Views.CustomerType;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.time.LocalDate;
import java.util.Random;
import java.util.ResourceBundle;

public class AddNewCustomerController implements Initializable {

    public ChoiceBox<CustomerType> customer_selector;
    public TextField fName_fld;
    public TextField lName_fld;
    public TextField address_fld;

    public TextField gender_fld;

    public CheckBox id_box;
    public PasswordField password_fld;
    public ChoiceBox<BankAccountType> bank_acc_selector;
    public CheckBox aNumber_box;
    public Label aNumber_lbl;

    public CheckBox sCode_box;

    public Label sCode_lbl;
    public Button add_new_customer_btn;

    public Label error_lbl;

    public DatePicker date_created;

    public TextField acc_bala_fld;




    //add Card//
    public TextField acc_n_fld;
    public TextField card_name_fld;
    public TextField card_num_fld;
    public TextField cvc_fld;
    public TextField credit_fld;

    public DatePicker issue_date;
    public DatePicker expired_date;
    public TextField confirm_pin_fld;
    public TextField pin_fld;
    public TextField max_limit_fld;
    public TextField card_type_fld;
    public Button Confirm_card_btn;


    @FXML
    private Label msg1;

    @FXML
    private Label msg2;

    public AddNewCustomerController(Label msg1, Label msg2) {
        this.msg1 = msg1;
        this.msg2 = msg2;
    }


    boolean createRewardAccountFlag = false;
    boolean createBasicAccountFlag = false;
    boolean createIsaAccountFlag = false;



    private String accountNumber;

    private String sortCode;








    @FXML
    void addCard(ActionEvent event) {
        String acno, cardno, cardname, cvc, issue, expire, credit, cardtype, maxlimit, pin, confpin;
        acno = acc_n_fld.getText();
        cardno = card_num_fld.getText();
        cardname = card_name_fld.getText();
        cvc = cvc_fld.getText();
        credit = credit_fld.getText();
        issue = issue_date.getValue().toString(); // Assuming issue_date is a DatePicker
        expire = expired_date.getValue().toString(); // Assuming expired_date is a DatePicker
        cardtype = card_type_fld.getText();
        maxlimit = max_limit_fld.getText();
        pin = pin_fld.getText();
        confpin = confirm_pin_fld.getText();

        if (pin.equals(confpin)) {
            // Simulating the card info insertion into a database
            // Replace this simulation with your actual database handling code
            simulateCardInsertion(acno, cardno, cardname, cardtype, pin, cvc, issue, expire, credit, maxlimit);
        } else {
            msg2.setText("Pin doesn't match. Unsuccessful");
        }
    }

    private void simulateCardInsertion(String acno, String cardno, String cardname, String cardtype, String pin,
                                       String cvc, String issue, String expire, String credit, String maxlimit) {
        // Simulating the card info insertion (Print to console for simulation)
        System.out.println("Simulating card info insertion:");
        System.out.println("Account Number: " + acno);
        System.out.println("Card Number: " + cardno);
        System.out.println("Card Name: " + cardname);
        System.out.println("Card Type: " + cardtype);
        System.out.println("PIN: " + pin);
        System.out.println("CVC: " + cvc);
        System.out.println("Issue Date: " + issue);
        System.out.println("Expiration Date: " + expire);
        System.out.println("Credit: " + credit);
        System.out.println("Max Limit: " + maxlimit);

        msg2.setText("Card successfully Added."); // Update UI or message
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        add_new_customer_btn.setOnAction(event -> addNewCustomer());
        sCode_box.selectedProperty().addListener((observableValue, oldVal, newVal) -> {
            if (newVal) {
                sortCode = createSortCode();
                onCreateSortCode();
            }
        });
        aNumber_box.selectedProperty().addListener((observableValue, oldVal, newVal) -> {
            if (newVal) {
                accountNumber = createAccountNumber();
                onCreateAccountNumber();
            }
        });

        customer_selector.setItems(FXCollections.observableArrayList(CustomerType.INDIVIDUAL, CustomerType.BUSINESS, CustomerType.CHARITY));
        bank_acc_selector.setItems(FXCollections.observableArrayList(BankAccountType.REWARD_ACCOUNT, BankAccountType.BASIC_ACCOUNT, BankAccountType.ISA_ACCOUNT));
        bank_acc_selector.getSelectionModel().selectedItemProperty().addListener((observableValue, oldVal, newVal) -> {
            switch (newVal) {
                case REWARD_ACCOUNT:
                    handleRewardAccountSelection();
                    break;
                case BASIC_ACCOUNT:
                    handleBasicAccountSelection();
                    break;
                case ISA_ACCOUNT:
                    handleIsaAccountSelection();
                    break;
                default:
                    // Handle default behavior or error for unsupported account type
                    break;
            }
        });
    }



    private void handleRewardAccountSelection() {
        RewardAccount rewardAccount = new RewardAccount(accountNumber, "", 0);
        rewardAccount.processCardTransaction(0); // Pass appropriate parameters
        rewardAccount.applyInterest();
        int interestRate = rewardAccount.getInterestRate();
        rewardAccount.setInterestRate(0); // Set an appropriate interest rate
    }

    private void handleBasicAccountSelection() {
        BasicAccount basicAccount = new BasicAccount(accountNumber, "", 0);
        basicAccount.processCardTransaction(0); // Pass appropriate parameters
    }

    private void handleIsaAccountSelection() {
        IsaAccount isaAccount = new IsaAccount(accountNumber, "", 0);
        isaAccount.applyInterest();
        int interestRate = isaAccount.getInterestRate();
        isaAccount.setInterestRate(0); // Set an appropriate interest rate
    }


    private void addNewCustomer() {

        // Create Checking account
        if (createRewardAccountFlag){
            createAccount("Reward");
        }
        // Create Savings Account
        if (createBasicAccountFlag){
            createAccount("Basic");
        }

        if (createIsaAccountFlag){
            createAccount("Isa");
        }
        // Create Client
        String fName = fName_fld.getText();
        String lName = lName_fld.getText();
        String password = password_fld.getText();
        Model.getInstance().getDatabaseDriver().addNewCustomer(fName, lName, accountNumber, password, LocalDate.now());
        error_lbl.setStyle("-fx-text-fill: blue; -fx-font-size: 1.3em; -fx-font-weight: bold");
        error_lbl.setText("Customer Created Successfully!");
        emptyFields();
    }

    // Implement or remove undefined methods
    private void createAccount(String bankAccountType) {
        double balance = Double.parseDouble(acc_bala_fld.getText());
        // Generate Account Number
        String firstSection = "3201";
        String lastSection = Integer.toString((new Random()).nextInt(9999) + 1000);
        String accountNumber = firstSection + " " + lastSection;

        switch (bankAccountType) {
            case "Reward":
                Model.getInstance().getDatabaseDriver().createRewardAccount(accountNumber, sortCode, balance);
                break;
            case "BASIC":
                Model.getInstance().getDatabaseDriver().createBasicAccount(accountNumber, sortCode, balance);
                break;
            case "ISA":
                Model.getInstance().getDatabaseDriver().createISAAccount(accountNumber, sortCode, balance);
                break;
            default:
                // Handle default behavior or error for unsupported account type
                throw new IllegalArgumentException("Unsupported Bank account type");
        }
    }


    private void onCreateAccountNumber() {
        if (fName_fld.getText() != null && lName_fld.getText() != null){
            String accountNumber = generateAccountNumber();
            aNumber_lbl.setText(accountNumber);
        }
    }

    private void onCreateSortCode() {
        if (fName_fld.getText() != null && lName_fld.getText() != null){
            String sortCode = generateSortCode();
            sCode_lbl.setText(sortCode);
        }
    }

    private String createAccountNumber() {
        int id = Model.getInstance().getDatabaseDriver().getLastCustomersId() + 1;
        char fChar = Character.toLowerCase(fName_fld.getText().charAt(0));
        return "ACC" + fChar + lName_fld.getText() + id; // Modify the account number format as needed
    }

    private String createSortCode() {
        Random random = new Random();
        int firstSection = random.nextInt(10000);
        return String.format("%04d", firstSection); // Formats the random number as a 4-digit string
    }


    private void emptyFields() {
        fName_fld.setText("");
        lName_fld.setText("");
        password_fld.setText("");
        aNumber_box.setSelected(false);
        aNumber_lbl.setText("");
        sCode_box.setSelected(false);
        sCode_lbl.setText("");

        customer_selector.getSelectionModel().clearSelection();
        bank_acc_selector.getSelectionModel().clearSelection();
    }
}

