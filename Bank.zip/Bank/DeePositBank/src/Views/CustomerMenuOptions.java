package com.example.deepositbank.Views;

public enum CustomerMenuOptions {

    DASHBOARD,

    TRANSACTIONS,

    ACCOUNTS,

    PROFILE,

    REPORT,
    SETTING,

}
