package com.example.deepositbank.Models;

import javafx.beans.binding.BooleanExpression;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.time.LocalDate;
import java.util.List;

public class Customer {
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty accountNumber;
    private final StringProperty sortCode;
    private final ObjectProperty<SavingsAccount> rewardAccount;
    private final ObjectProperty<CurrentAccount> basicAccount;
    private final ObjectProperty<SavingsAccount> isaAccount;

    private final ObjectProperty<Boolean> editProperty;
    private final ObjectProperty<Boolean> deleteProperty;

    private final ObjectProperty<LocalDate> dateCreated;

    private final StringProperty visa = new SimpleStringProperty();
    private List<Object> visaCardProperties;


    public Customer(String fName, String lName, String aNumber, String sCode,
                    SavingsAccount rAccount, CurrentAccount bAccount, SavingsAccount iAccount, String visa, LocalDate date) {
        this.firstName = new SimpleStringProperty(this, "FirstName", fName);
        this.lastName = new SimpleStringProperty(this, "LastName", lName);
        this.accountNumber = new SimpleStringProperty(this, "Account Number", aNumber);
        this.sortCode = new SimpleStringProperty(this, "Sort Code", sCode);
        this.rewardAccount = new SimpleObjectProperty<>(this, "Reward Account", rAccount);
        this.basicAccount = new SimpleObjectProperty<>(this, "Basic Account", bAccount);
        this.isaAccount = new SimpleObjectProperty<>(this, "Isa Account", iAccount);
        this.editProperty = new SimpleObjectProperty<>(false); // Initialize with default values
        this.deleteProperty = new SimpleObjectProperty<>(false); // Initialize with default values
        this.dateCreated = new SimpleObjectProperty<>(this, "Date", date);
    }

    // Getters and setters for properties
    public StringProperty firstNameProperty() {
        return firstName;
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public StringProperty accountNumberProperty() {
        return accountNumber;
    }


    public ObjectProperty<Boolean> editProperty() {
        return editProperty;
    }

    public ObjectProperty<Boolean> deleteProperty() {
        return deleteProperty;
    }


    public StringProperty sortCodeProperty() {
        return sortCode;
    }

    public ObjectProperty<SavingsAccount> rewardAccountProperty() {
        return rewardAccount;
    }

    public ObjectProperty<CurrentAccount> basicAccountProperty() {
        return basicAccount;
    }

    public ObjectProperty<SavingsAccount> isaAccountProperty() {
        return isaAccount;
    }


    public ObjectProperty<LocalDate> dateCreatedProperty() {
        return dateCreated;
    }

    public String getFirstName() {
        return firstName.get();
    }

    public String getLastName() {
        return lastName.get();
    }


    public void setFirstName(String newFirstName) {
        firstName.set(newFirstName);
    }

    public void setLastName(String newLastName) {
        lastName.set(newLastName);
    }

    public ObjectProperty<LocalDate> dateProperty() {
        return dateCreated;
    }


    public List<Object> visaCardProperty() {
        return visaCardProperties;
    }


    public BooleanExpression viewDetails() {
    }
}