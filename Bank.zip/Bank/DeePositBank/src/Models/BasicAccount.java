package com.example.deepositbank.Models;

public class BasicAccount extends Account implements CurrentAccount {
    public BasicAccount(String accountNumber, String sortCode, int balance) {
        super(accountNumber, sortCode, balance);
    }

    @Override
    public void processCardTransaction(int amount) {
        // Logic for processing card transactions in a basic account
        // Implement your logic here
    }
}
