package com.example.deepositbank.Models;

import javafx.beans.property.*;


public abstract class Account {

    private final StringProperty accountNumber;

   private final StringProperty sortCode;

    private final SimpleIntegerProperty balance;

    public Account(String accountNumber, String sortCode, int balance){
        this.accountNumber = new SimpleStringProperty(this,"Account Number", accountNumber);
        this.sortCode = new SimpleStringProperty(this,"Sort Code", sortCode );
        this.balance = new SimpleIntegerProperty(this,"Balance", balance);
    }

    public StringProperty accountNumberProperty() {return accountNumber;}

    public StringProperty sortCodeProperty() {return sortCode;}

    public IntegerProperty balanceProperty() {return balance;}




}
