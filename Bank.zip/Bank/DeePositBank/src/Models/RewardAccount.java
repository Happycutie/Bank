package com.example.deepositbank.Models;

public class RewardAccount extends Account implements CurrentAccount, SavingsAccount {
    public RewardAccount(String accountNumber, String sortCode, int balance) {
        super(accountNumber, sortCode, balance);
    }

    @Override
    public void processCardTransaction(int amount) {
        // Logic for processing card transactions in a reward account
    }

    @Override
    public void applyInterest() {
        // Logic for applying interest to a reward account
    }

    @Override
    public int getInterestRate() {
        // Logic to get the interest rate of a reward account
        return 0; // Replace with actual logic
    }

    @Override
    public void setInterestRate(int rate) {
        // Logic to set the interest rate of a reward account
    }

    @Override
    public void deposit(double amount) {

    }

    @Override
    public void withdraw(double amount) {

    }
}
